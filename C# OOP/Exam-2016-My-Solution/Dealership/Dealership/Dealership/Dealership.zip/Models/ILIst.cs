﻿namespace Dealership.Models
{
    internal class ILIst<T>
    {
    }
}