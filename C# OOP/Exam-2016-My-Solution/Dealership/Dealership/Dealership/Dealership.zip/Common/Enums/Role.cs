﻿namespace Dealership.Common.Enums
{
    public enum Role
    {
        Normal = 0,
        VIP = 1,
        Admin = 2
    }
}
